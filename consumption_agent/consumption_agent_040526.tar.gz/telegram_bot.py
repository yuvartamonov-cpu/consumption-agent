#!/usr/bin/env python3
"""
Consumption Agent Telegram Bot
Команды:
  /start — приветствие
  /list  — инвентарь по категориям
  /alerts — активные алерты
  /add <название> [<цена>] [<категория>] — добавить товар
  /check — статистика
  /help — справка

Запуск: CONSUMPTION_BOT_TOKEN=xxx python3 telegram_bot.py
"""

import logging, os, sys, re, sqlite3, json, subprocess, tempfile
from datetime import date
from pathlib import Path

from telegram import Update, PhotoSize
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(SCRIPT_DIR, 'consumption.db')
RECEIPTS_DIR = os.path.join(SCRIPT_DIR, 'receipts')
Path(RECEIPTS_DIR).mkdir(exist_ok=True)
TOKEN = os.environ.get('CONSUMPTION_BOT_TOKEN', '')


def decode_qr(image_path: str) -> dict:
    """Decode QR code from image and return structured data."""
    from pyzbar.pyzbar import decode
    from PIL import Image
    try:
        decoded = decode(Image.open(image_path))
        if not decoded:
            return {}
        data = decoded[0].data.decode('utf-8', errors='replace')
        # Parse Ozon QR: "t=20260504T2051&s=1234.56&fn=9999078900005412&i=12345&fp=1234567890"
        result = {}
        for part in data.split('&'):
            if '=' in part:
                k, v = part.split('=', 1)
                result[k] = v
        return result
    except Exception as e:
        log.error(f"QR decode failed: {e}")
        return {}


def ocr_image(image_path: str) -> str:
    """Run Tesseract OCR on image and return extracted text."""
    try:
        result = subprocess.run(
            ['tesseract', image_path, 'stdout', '-l', 'rus+eng', '--psm', '6'],
            capture_output=True, text=True, check=True
        )
        text = result.stdout.strip()
        # Post-processing: remove garbage, normalize
        text = re.sub(r'[^\n\w\s.,%₽]', ' ', text)  # Keep only letters, numbers, prices
        text = re.sub(r'\s+', ' ', text).strip()
        return text
    except subprocess.CalledProcessError as e:
        log.error(f"OCR failed: {e.stderr}")
        return ""

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')
log = logging.getLogger(__name__)

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        '🛒 Consumption Agent\n\n'
        'Команды:\n'
        '/list — инвентарь по категориям\n'
        '/alerts — алерты (гарантии, сроки)\n'
        '/add <название> [<цена>] [<категория>] — добавить товар\n'
        '/add_photo — загрузить фото чека (OCR)\n'
        '/check — статистика\n'
        '/help — это сообщение'
    )

async def add_photo(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        '📸 Отправьте фото чека (одно фото за раз).\n'
        'Я распознаю текст и добавлю товары в инвентарь.'
    )


async def photo_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not update.message.photo:
        await update.message.reply_text('❌ Это не фото. Пожалуйста, отправьте изображение.')
        return

    # Get the highest resolution photo
    photo: PhotoSize = update.message.photo[-1]
    file = await photo.get_file()
    receipt_path = os.path.join(RECEIPTS_DIR, f'receipt_{update.message.message_id}.jpg')
    await file.download_to_drive(receipt_path)
    log.info(f'Saved receipt: {receipt_path}')

    # Decode QR code (Ozon format)
    qr_data = decode_qr(receipt_path)
    total_amount = None
    purchase_date = None
    if qr_data:
        total_amount = qr_data.get('s')  # Итоговая сумма (например, "1234.56")
        if total_amount:
            total_amount = float(total_amount)
        # Дата в формате "20260504T2051" → "2026-05-04"
        date_str = qr_data.get('t')
        if date_str and len(date_str) >= 8:
            purchase_date = f"{date_str[:4]}-{date_str[4:6]}-{date_str[6:8]}"

    # Run OCR as fallback
    text = ocr_image(receipt_path)
    items = []
    if text:
        for line in text.split('\n'):
            if 'итого' in line.lower() and not total_amount:
                match = re.search(r'(\d+[.,]\d{2})', line)
                if match:
                    total_amount = float(match.group(1).replace(',', '.'))
            # Try to parse items
            match = re.search(r'(.+?)\s+(\d+[.,]?\d*)\s*[x×]\s*(\d+[.,]?\d*)\s*[=≡]\s*(\d+[.,]?\d*)', line)
            if match:
                name, price, qty, total = match.groups()
                items.append({
                    'name': name.strip(),
                    'price': float(price.replace(',', '.')),
                    'qty': int(qty),
                    'total': float(total.replace(',', '.'))
                })

    # Save to DB
    conn = get_db()
    purchase_id = None
    if items or total_amount:
        # Save purchase record
        cur = conn.execute(
            "INSERT INTO purchases (purchase_date, total_amount, source_type) "
            "VALUES (?, ?, 'telegram_photo')",
            (purchase_date or date.today().isoformat(), total_amount)
        )
        purchase_id = cur.lastrowid

    if items:
        for item in items:
            # Try to guess category
            category_id = conn.execute(
                "SELECT id FROM categories WHERE name='Разное' LIMIT 1"
            ).fetchone()[0]
            for keyword, cat_slug in {
                'корм': 'cat_pets', 'собака': 'cat_pets', 'кошка': 'cat_pets',
                'доставка': 'cat_services', 'услуга': 'cat_services',
                'еда': 'cat_food', 'продукты': 'cat_food'
            }.items():
                if keyword in item['name'].lower():
                    cat_row = conn.execute(
                        "SELECT id FROM categories WHERE slug=? LIMIT 1", (cat_slug,)
                    ).fetchone()
                    if cat_row:
                        category_id = cat_row[0]
                        break
            conn.execute(
                "INSERT INTO items (name, purchase_price, purchase_date, category_id, source_type, purchase_id) "
                "VALUES (?, ?, ?, ?, 'telegram_photo', ?)",
                (item['name'], item['price'], purchase_date or date.today().isoformat(), category_id, purchase_id)
            )
        response_text = f'✅ Добавлено {len(items)} товаров:\n' + '\n'.join(f"- {item['name']}: {item['price']} ₽" for item in items)
    else:
        response_text = f'✅ Добавлена покупка на сумму {total_amount} ₽' if total_amount else '❌ Не удалось распознать чек.'

    conn.commit()
    conn.close()
    await update.message.reply_text(response_text)


async def cmd_list(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    conn = get_db()
    total = conn.execute("SELECT COUNT(*) FROM items WHERE deleted_at IS NULL").fetchone()[0]
    rows = conn.execute("""
        SELECT c.name, COUNT(i.id) as cnt, COALESCE(SUM(i.purchase_price), 0) as total_p
        FROM items i JOIN categories c ON i.category_id = c.id
        WHERE i.deleted_at IS NULL
        GROUP BY c.name ORDER BY cnt DESC
    """).fetchall()
    conn.close()
    lines = [f'📦 Инвентарь: {total} товаров\n']
    for r in rows:
        lines.append(f'• {r["name"]}: {r["cnt"]} шт. ({r["total_p"]:.0f} ₽)')
    lines.append(f'\nВсего категорий: {len(rows)}')
    await update.message.reply_text('\n'.join(lines))

async def cmd_alerts(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    conn = get_db()
    rows = conn.execute("SELECT alert_type,title,message FROM alerts WHERE status='pending' ORDER BY created_at").fetchall()
    conn.close()
    if not rows:
        await update.message.reply_text('✅ Нет активных алертов')
        return
    icons = {'warranty_expiring':'⚠️','warranty_expired':'❌','expiry_approaching':'⏳','expired':'🚫','low_stock':'📉','price_drop':'💰'}
    lines = ['🔔 Активные алерты:\n']
    for r in rows:
        icon = icons.get(r['alert_type'], '🔔')
        lines.append(f'{icon} {r["title"]}')
        if r['message']:
            lines.append(f'   {r["message"]}')
    await update.message.reply_text('\n'.join(lines))

async def cmd_check(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    conn = get_db()
    c = conn.cursor()
    data = {}
    for q, lab in [
        ("SELECT COUNT(*) FROM items WHERE deleted_at IS NULL","Товаров"),
        ("SELECT COUNT(*) FROM purchases WHERE deleted_at IS NULL","Покупок"),
        ("SELECT COUNT(*) FROM items WHERE warranty_months IS NOT NULL AND deleted_at IS NULL","С гарантией"),
        ("SELECT COUNT(*) FROM items WHERE lifespan_months IS NOT NULL AND deleted_at IS NULL","Со сроком годности"),
        ("SELECT COUNT(*) FROM categories","Категорий"),
        ("SELECT COUNT(*) FROM alerts WHERE status='pending'","Алертов"),
    ]:
        data[lab] = c.execute(q).fetchone()[0]
    conn.close()
    lines = ['📊 Статистика:\n']
    for k, v in data.items():
        lines.append(f'{k}: {v}')
    await update.message.reply_text('\n'.join(lines))

async def cmd_add(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    text = ' '.join(ctx.args)
    if not text:
        await update.message.reply_text('❌ Пример: /add Носки 350 одежда')
        return
    # Parse: name, optional price, optional category
    parts = text.rsplit(None, 2)  # try splitting from right
    name = text
    price = None
    category = None
    # Try category extraction
    cats = {'еда':'cat_food','продукты':'cat_food','одежда':'cat_clothing','обувь':'cat_clo_shoes',
            'техника':'cat_tech','книги':'cat_culture_books','спорт':'cat_sport','косметика':'cat_cosmetics',
            'здоровье':'cat_health','дом':'cat_home','авто':'cat_auto','животные':'cat_pets',
            'мебель':'cat_home_furn','аксесс':'cat_clo_access','хобби':'cat_hobbies'}
    for kw, cid in cats.items():
        if kw in text.lower():
            # Extract price before category
            m = re.search(r'(\d[\d\s]*\d)\s*(?:₽|руб|р)?', text)
            if m:
                price = float(m.group(1).replace(' ', ''))
                name = text[:m.start()].strip().rstrip(',').strip()
                try:
                    name = name.rsplit(None, 1)[0] if name.split()[-1].lower() == kw else name
                except: pass
            else:
                name = text.replace(kw, '').strip().strip(',').strip()
            category = cid
            break
    if not category:
        m = re.search(r'(\d[\d\s]*\d)\s*(?:₽|руб|р)?', text)
        if m:
            price = float(m.group(1).replace(' ', ''))
            name = text[:m.start()].strip().rstrip(',').strip()
    if not name or len(name) < 2:
        await update.message.reply_text('❌ Слишком короткое название')
        return
    conn = get_db()
    cat_id = None
    if category:
        row = conn.execute("SELECT id FROM categories WHERE id=? OR slug=? LIMIT 1", (category, category)).fetchone()
        if row: cat_id = row[0]
    if cat_id is None:
        row = conn.execute("SELECT id FROM categories WHERE slug='other' LIMIT 1").fetchone()
        if row: cat_id = row[0]
    cur = conn.execute("INSERT INTO items (name,purchase_price,purchase_date,category_id,status,quantity,data_origin) VALUES (?,?,?,?,'in_use',1,'telegram')",
                       (name.strip(), price, date.today().isoformat(), cat_id))
    conn.commit()
    conn.close()
    await update.message.reply_text(f'✅ Добавлено: {name.strip()}{f" ({price:.0f} ₽)" if price else ""}')

async def cmd_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await start(update, ctx)

def main():
    if not TOKEN:
        print('❌ Укажите CONSUMPTION_BOT_TOKEN')
        print('   export CONSUMPTION_BOT_TOKEN=...')
        sys.exit(1)
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler('start', start))
    app.add_handler(CommandHandler('list', cmd_list))
    app.add_handler(CommandHandler('alerts', cmd_alerts))
    app.add_handler(CommandHandler('check', cmd_check))
    app.add_handler(CommandHandler('add', cmd_add))
    app.add_handler(CommandHandler('add_photo', add_photo))
    app.add_handler(CommandHandler('help', cmd_help))
    app.add_handler(MessageHandler(filters.PHOTO, photo_handler))
    log.info('Bot started, polling...')
    app.run_polling()

if __name__ == '__main__':
    main()
